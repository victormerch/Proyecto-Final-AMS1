package Ejemplo;

public class Ejemplo {

	public static void main(String[] args) {
		int contRounds = 0;
		int contTourn = 0;
		int num1 = (int) Math.floor(Math.random()*(3-1+1)+1);
		int num2 = (int) Math.floor(Math.random()*(3-1+1)+1);
		Player player1 = null, player2 = null, user = null, bot = null;
		
		System.out.println(num1);
		System.out.println(num2);
		//Seleccion Raza Persona
		if (num1 == 1) {
			System.out.println("Ets un nan");
			user = new Player("Nan", 60, 6, 4, 5, 3);
		}
		else if (num1 == 2) {
			System.out.println("Ets un huma");
			user = new Player("Human", 50, 5, 3, 6, 5);
		}
		
		else if (num1 == 3) {
			System.out.println("Ets un elf");
			user = new Player("Elf", 40, 4, 2, 7, 7);
		}
		
		//Seleccion Raza Bot
		if (num2 == 1) {
			System.out.println("Ets un nan");
			bot = new Player("Nan", 60, 6, 4, 5, 3);
		}
		else if (num2 == 2) {
			System.out.println("Ets un huma");
			bot = new Player("Human", 50, 5, 3, 6, 5);
		}
		
		else if (num2 == 3) {
			System.out.println("Ets un elf");
			bot = new Player("Elf", 40, 4, 2, 7, 7);
		}
		
		if (user.getWarriorVel() > bot.getWarriorVel()) {
			player1 = user;
			player2 = bot;
		}

		else if (bot.getWarriorVel() > user.getWarriorVel()) {
			player1 = bot;
			player2 = user;

		}

		else if (bot.getWarriorVel() == user.getWarriorVel()) {
			if (user.getWarriorAgil() > bot.getWarriorAgil()) {
				player1 = user;
				player2 = bot;

			}

			else if (bot.getWarriorAgil() > user.getWarriorAgil()) {
				player1 = bot;
				player2 = user;

			}
			
			else if (bot.getWarriorAgil() == user.getWarriorAgil()) {
				player1 = user;
				player2 = bot;
			}
			

		}
		System.out.println("Empieza " + player1.getName());

		while (bot.getLife() > 0 && user.getLife() > 0) {
			contRounds++;
			contTourn++;
			player1.setLife(player1.getLife() - player2.getAtack());
			System.out.println("1: "+ player1.getName() + " tiene " + player1.getLife());
			if (player1.getLife() > 0) {
				player2.setLife(player2.getLife() - player1.getAtack());
				System.out.println("2: "+player2.getName() + " tiene " + player2.getLife());
			}

			if (player2.getLife() < 1) {
				System.out.println("2:" + player2.getName() + " ha sido derrotado");
			}
			if (player1.getLife() < 1) {
				System.out.println("1: " + player1.getName() + " ha sido derrotado");
			}
		}

	}
}
