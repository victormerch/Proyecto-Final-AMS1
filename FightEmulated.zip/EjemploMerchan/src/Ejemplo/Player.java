package Ejemplo;

public class Player {
	String name;
	int WarriorVel;
	int WarriorAgil;
	int Life;
	int Atack;
	int Def;
	
	public Player(String name,int life,int atack,int def, int warriorAgil, int warriorVel) {
		super();
		this.name = name;
		WarriorVel = warriorVel;
		WarriorAgil = warriorAgil;
		Life = life;
		Atack = atack;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getWarriorVel() {
		return WarriorVel;
	}
	public void setWarriorVel(int warriorVel) {
		WarriorVel = warriorVel;
	}
	public int getWarriorAgil() {
		return WarriorAgil;
	}
	public void setWarriorAgil(int warriorAgil) {
		WarriorAgil = warriorAgil;
	}
	public int getLife() {
		return Life;
	}
	public void setLife(int life) {
		Life = life;
	}
	public int getAtack() {
		return Atack;
	}
	public void setAtack(int atack) {
		Atack = atack;
	}
	

	
	
	
	
}
